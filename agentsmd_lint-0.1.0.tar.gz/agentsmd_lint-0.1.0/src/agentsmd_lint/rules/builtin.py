"""Built-in lint rules for AGENTS.md.

Design philosophy (from the AGENTS.md spec + Gloaguen et al. 2026 research):
the format has *no required fields*, so this linter does not enforce a schema.
Instead it optimises for **signal density** - catching low-value, vague, or
duplicated content that research shows degrades agent performance, while nudging
authors toward the high-signal sections real repositories converge on.
"""
from __future__ import annotations

import re
from typing import Iterable

from ..models import Document, Finding, Severity
from ..parser import iter_code_blocks
from .base import RuleConfig, rule

# ---- shared heuristics -----------------------------------------------------

# Phrases that signal vague, low-signal guidance an agent cannot act on.
_VAGUE_PHRASES = [
    "write good code",
    "write clean code",
    "be careful",
    "use best practices",
    "follow best practices",
    "high quality",
    "as needed",
    "where appropriate",
    "make sure it works",
    "do the right thing",
    "keep it simple",
]

# Openers that typically indicate content copied from a human README rather
# than agent-specific, non-obvious instructions.
_README_ECHO_PATTERNS = [
    r"\bthis (project|repository|repo) is\b",
    r"\bwelcome to\b",
    r"\b(getting started|table of contents)\b",
    r"\bfeatures\b\s*:?\s*$",
]

# Tell-tale fragments of unedited, auto-generated (/init) output.
_LLM_BOILERPLATE = [
    "as an ai",
    "here is a",
    "here's a",
    "this file was generated",
    "todo: fill",
    "tbd",
    "lorem ipsum",
    "<placeholder",
    "xxx",
]

_COMMAND_HINT_SECTIONS = ("build", "test", "setup", "run", "install", "dev")


def _backtick_spans(line: str) -> list[str]:
    """Return the text inside each `backtick` span on a line."""
    return re.findall(r"`([^`]+)`", line)


def _looks_like_command(line: str) -> bool:
    tokens = line.strip().split()
    if not tokens:
        return False
    common = {
        "npm", "pnpm", "yarn", "npx", "pip", "python", "python3", "pytest",
        "make", "cargo", "go", "docker", "poetry", "uv", "ruff", "black",
        "eslint", "vitest", "jest", "tox", "bash", "sh", "./", "mvn", "gradle",
    }
    first = tokens[0].lower().rstrip(":")
    return first in common or first.startswith("./")


# ---- rules -----------------------------------------------------------------

@rule("AM001", "File is non-empty and has at least one heading")
def has_structure(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    if not doc.raw.strip():
        yield Finding("AM001", Severity.ERROR, "AGENTS.md is empty.")
        return
    if not doc.sections:
        yield Finding(
            "AM001",
            Severity.ERROR,
            "No Markdown headings found. Use '#' headings so agents can locate sections.",
            hint="Add at least a top-level title, e.g. '# Project'.",
        )


@rule("AM002", "Document has a single top-level (H1) title")
def single_h1(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    h1s = [s for s in doc.sections if s.level == 1]
    if not h1s:
        yield Finding(
            "AM002",
            Severity.WARNING,
            "No H1 title found. Start the file with a single '# Title'.",
            line=1,
        )
    elif len(h1s) > 1:
        for extra in h1s[1:]:
            yield Finding(
                "AM002",
                Severity.WARNING,
                f"Multiple H1 titles; '{extra.title}' should be H2 or lower.",
                line=extra.start_line,
            )


@rule("AM010", "Recommends high-signal sections most repos include")
def recommended_coverage(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    titles = " ".join(doc.heading_titles())
    present = {s for s in config.recommended_sections if s in titles}
    # We only nudge; the spec has no required fields.
    if not present:
        yield Finding(
            "AM010",
            Severity.WARNING,
            "None of the common high-signal sections were found "
            "(setup, build, test, code style, security, commit/PR).",
            hint="Add the ones that carry non-obvious, agent-relevant instructions.",
        )


@rule("AM011", "At least one section provides runnable commands")
def has_commands(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    command_sections = 0
    for section in doc.sections:
        blocks = iter_code_blocks(section)
        has_cmd = any(
            _looks_like_command(line) for block in blocks for line in block
        )
        # bullet-style commands (`- run \`pnpm test\``) count too: inspect the
        # content inside backtick spans on each line.
        if not has_cmd:
            has_cmd = any(
                _looks_like_command(span)
                for line in section.body_lines
                for span in _backtick_spans(line)
            )
        if has_cmd:
            command_sections += 1

    if command_sections < config.min_command_sections:
        yield Finding(
            "AM011",
            Severity.WARNING,
            "No concrete build/test/run commands found.",
            hint="Agents work best with exact commands, e.g. `pytest -q` or `pnpm test`.",
        )


@rule("AM020", "Flags vague, unactionable guidance")
def vague_guidance(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    for idx, line in enumerate(doc.lines, start=1):
        low = line.lower()
        for phrase in _VAGUE_PHRASES:
            if phrase in low:
                yield Finding(
                    "AM020",
                    Severity.WARNING,
                    f"Vague instruction: '{phrase}'. Agents cannot act on this.",
                    line=idx,
                    hint="Replace with a concrete, checkable rule "
                    "(e.g. 'keep functions under 40 lines').",
                )
                break


@rule("AM021", "Flags content that appears copied from the README")
def readme_echo(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    # Research: duplicating repo-evident content inflates agent cost ~23%.
    for section in doc.sections:
        text = section.body_text.lower()
        for pat in _README_ECHO_PATTERNS:
            if re.search(pat, text):
                yield Finding(
                    "AM021",
                    Severity.INFO,
                    f"Section '{section.title}' reads like README prose "
                    "the agent can already infer from the repo.",
                    line=section.start_line,
                    hint="Keep only non-obvious, agent-specific context here.",
                )
                break


@rule("AM022", "Flags unedited auto-generated / placeholder content")
def llm_boilerplate(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    for idx, line in enumerate(doc.lines, start=1):
        low = line.lower()
        for frag in _LLM_BOILERPLATE:
            if frag in low:
                yield Finding(
                    "AM022",
                    Severity.ERROR,
                    f"Placeholder / generated content detected: '{frag}'.",
                    line=idx,
                    hint="Edit or remove. Unedited /init output degrades agent runs.",
                )
                break


@rule("AM030", "Whole file stays within a healthy length budget")
def length_budget(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    words = len(doc.raw.split())
    if words > config.max_words:
        yield Finding(
            "AM030",
            Severity.WARNING,
            f"File is {words} words (> {config.max_words}). "
            "Long context files raise cost and dilute signal.",
            hint="Move detail into linked docs; keep AGENTS.md high-signal.",
        )


@rule("AM031", "Individual sections stay concise")
def section_length(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    for section in doc.sections:
        if section.word_count > config.max_section_words:
            yield Finding(
                "AM031",
                Severity.INFO,
                f"Section '{section.title}' is {section.word_count} words; "
                "consider trimming or splitting.",
                line=section.start_line,
            )


@rule("AM040", "No empty sections")
def empty_sections(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    for section in doc.sections:
        # A heading whose only content is more sub-headings is fine.
        has_content = bool(section.body_text) or any(
            other.level > section.level
            and other.start_line > section.start_line
            for other in doc.sections
        )
        if not has_content:
            yield Finding(
                "AM040",
                Severity.WARNING,
                f"Section '{section.title}' is empty.",
                line=section.start_line,
                hint="Fill it with actionable content or remove the heading.",
            )


@rule("AM041", "Bare URLs should be Markdown links or annotated")
def bare_reference(doc: Document, config: RuleConfig) -> Iterable[Finding]:
    url_re = re.compile(r"(?<!\()https?://\S+")
    fence = False
    for idx, line in enumerate(doc.lines, start=1):
        if line.strip().startswith("```"):
            fence = not fence
            continue
        if fence:
            continue
        if url_re.search(line) and "](http" not in line:
            yield Finding(
                "AM041",
                Severity.INFO,
                "Bare URL found; prefer a labelled Markdown link so agents "
                "know why the reference matters.",
                line=idx,
            )
