"""Rule package. Importing this registers all built-in rules."""
from . import builtin  # noqa: F401  (import for side effect: registration)
from .base import Rule, RuleConfig, all_rules, rule

__all__ = ["Rule", "RuleConfig", "all_rules", "rule"]
