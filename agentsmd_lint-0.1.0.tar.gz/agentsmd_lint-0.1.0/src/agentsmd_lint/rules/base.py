"""Rule infrastructure: base class, registry, and configuration."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable

from ..models import Document, Finding

# A rule is any callable that inspects a Document and yields Findings.
RuleFunc = Callable[[Document, "RuleConfig"], Iterable[Finding]]


@dataclass
class RuleConfig:
    """Per-run configuration, populated from defaults + user config file."""

    # Sections that, if present, count toward "recommended coverage".
    recommended_sections: list[str] = field(
        default_factory=lambda: [
            "overview",
            "setup",
            "build",
            "test",
            "testing",
            "code style",
            "conventions",
            "security",
            "commit",
            "pull request",
            "pr",
        ]
    )
    max_words: int = 1500
    max_section_words: int = 400
    min_command_sections: int = 1
    disabled_rules: set[str] = field(default_factory=set)

    def is_enabled(self, rule_id: str) -> bool:
        return rule_id not in self.disabled_rules


@dataclass
class Rule:
    """A named, documented lint rule."""

    id: str
    summary: str
    func: RuleFunc

    def run(self, doc: Document, config: RuleConfig) -> list[Finding]:
        if not config.is_enabled(self.id):
            return []
        return list(self.func(doc, config))


_REGISTRY: list[Rule] = []


def rule(rule_id: str, summary: str) -> Callable[[RuleFunc], RuleFunc]:
    """Decorator that registers a rule function."""

    def decorator(func: RuleFunc) -> RuleFunc:
        _REGISTRY.append(Rule(id=rule_id, summary=summary, func=func))
        return func

    return decorator


def all_rules() -> list[Rule]:
    return list(_REGISTRY)
