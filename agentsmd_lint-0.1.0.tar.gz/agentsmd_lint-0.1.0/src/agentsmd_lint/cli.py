"""Command-line interface for agentsmd-lint."""
from __future__ import annotations

import argparse
import glob
import os
import sys

from . import __version__
from .config import load_config
from .linter import lint_file, lint_text
from .reporters import pretty, to_json
from .rules import RuleConfig, all_rules
from .scaffold import render

_DEFAULT_GLOB = "**/AGENTS.md"


def _find_files(paths: list[str]) -> list[str]:
    found: list[str] = []
    for p in paths:
        if os.path.isdir(p):
            found.extend(glob.glob(os.path.join(p, _DEFAULT_GLOB), recursive=True))
        elif any(ch in p for ch in "*?["):
            found.extend(glob.glob(p, recursive=True))
        else:
            found.append(p)
    # de-dupe, stable order
    seen: set[str] = set()
    unique = []
    for f in found:
        if f not in seen:
            seen.add(f)
            unique.append(f)
    return unique


def _cmd_lint(args: argparse.Namespace) -> int:
    targets = args.paths or ["."]
    files = _find_files(targets)
    if not files:
        print("No AGENTS.md files found.", file=sys.stderr)
        return 1

    config = load_config(args.config_dir) if not args.no_config else RuleConfig()
    if args.disable:
        config.disabled_rules |= {r.upper() for r in args.disable}

    results = []
    for path in files:
        try:
            results.append(lint_file(path, config))
        except FileNotFoundError:
            print(f"File not found: {path}", file=sys.stderr)
            return 1

    if args.format == "json":
        print(to_json(results))
    else:
        for i, r in enumerate(results):
            if i:
                print()
            pretty(r)

    worst = min((r.score for r in results), default=100)
    has_error = any(not r.ok for r in results)
    below_threshold = worst < args.min_score

    if has_error or below_threshold:
        return 1
    return 0


def _cmd_init(args: argparse.Namespace) -> int:
    content = render(project=args.name, stack=args.stack)
    target = args.output
    if os.path.exists(target) and not args.force:
        print(f"{target} already exists. Use --force to overwrite.", file=sys.stderr)
        return 1
    with open(target, "w", encoding="utf-8") as fh:
        fh.write(content)
    print(f"Wrote {target}")
    # Show it passes our own linter - dogfooding builds trust.
    result = lint_text(target, content)
    print(f"Starter file scores {result.score}/100.")
    return 0


def _cmd_rules(args: argparse.Namespace) -> int:
    for rule in all_rules():
        print(f"{rule.id}  {rule.summary}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentsmd-lint",
        description="Lint and scaffold AGENTS.md files for high signal density.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_lint = sub.add_parser("lint", help="Lint one or more AGENTS.md files.")
    p_lint.add_argument("paths", nargs="*", help="Files, dirs, or globs (default: .).")
    p_lint.add_argument("--format", choices=["pretty", "json"], default="pretty")
    p_lint.add_argument("--min-score", type=int, default=0,
                        help="Exit non-zero if any file scores below this (0-100).")
    p_lint.add_argument("--disable", nargs="*", default=[], help="Rule IDs to disable.")
    p_lint.add_argument("--config-dir", default=".", help="Where to look for config.")
    p_lint.add_argument("--no-config", action="store_true", help="Ignore config files.")
    p_lint.set_defaults(func=_cmd_lint)

    p_init = sub.add_parser("init", help="Create a high-signal starter AGENTS.md.")
    p_init.add_argument("--name", default="Project", help="Project name for the title.")
    p_init.add_argument("--stack", choices=["python", "node", "generic"], default="generic")
    p_init.add_argument("--output", default="AGENTS.md", help="Output path.")
    p_init.add_argument("--force", action="store_true", help="Overwrite if it exists.")
    p_init.set_defaults(func=_cmd_init)

    p_rules = sub.add_parser("rules", help="List all lint rules.")
    p_rules.set_defaults(func=_cmd_rules)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
