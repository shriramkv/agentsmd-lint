"""Core data models for agentsmd-lint."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Severity(str, Enum):
    """Severity levels for lint findings, ordered from most to least serious."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"

    @property
    def rank(self) -> int:
        return {"error": 3, "warning": 2, "info": 1}[self.value]


@dataclass(frozen=True)
class Finding:
    """A single lint result tied to a rule and (optionally) a line."""

    rule_id: str
    severity: Severity
    message: str
    line: Optional[int] = None
    hint: Optional[str] = None

    def location(self) -> str:
        return f"{self.line}" if self.line is not None else "-"


@dataclass
class Section:
    """A parsed Markdown section: a heading plus the lines beneath it."""

    title: str
    level: int
    start_line: int
    body_lines: list[str] = field(default_factory=list)

    @property
    def normalized_title(self) -> str:
        return self.title.strip().lower()

    @property
    def body_text(self) -> str:
        return "\n".join(self.body_lines).strip()

    @property
    def word_count(self) -> int:
        return len(self.body_text.split())


@dataclass
class Document:
    """A parsed AGENTS.md document."""

    path: str
    raw: str
    lines: list[str]
    sections: list[Section]
    has_frontmatter: bool = False

    def heading_titles(self) -> list[str]:
        return [s.normalized_title for s in self.sections]
