"""Generate a high-signal starter AGENTS.md that passes the linter.

The template embodies the tool's own advice: concrete commands, no vague
guidance, no README echo, no placeholder bloat.
"""
from __future__ import annotations

TEMPLATE = """# {project}

## Overview
{overview}

## Setup
- Install dependencies: `{install_cmd}`
- Requires: {runtime}

## Build
- Build the project: `{build_cmd}`

## Testing
- Run the full suite: `{test_cmd}`
- Run a single test: `{single_test_cmd}`
- All tests must pass before a change is considered complete.

## Code style
- {style_rule}
- Keep functions small and single-purpose; prefer clarity over cleverness.

## Security
- Never commit secrets, tokens, or `.env` files.
- Do not modify files under {protected_paths} without explicit instruction.

## Commit & PR
- Use conventional commit messages (e.g. `feat:`, `fix:`, `docs:`).
- Run tests and the linter before opening a pull request.
"""

_PRESETS = {
    "python": {
        "install_cmd": "pip install -e '.[dev]'",
        "runtime": "Python 3.10+",
        "build_cmd": "python -m build",
        "test_cmd": "pytest -q",
        "single_test_cmd": 'pytest -q -k "<test_name>"',
        "style_rule": "Format with `ruff format`; lint with `ruff check`.",
    },
    "node": {
        "install_cmd": "pnpm install",
        "runtime": "Node 20+",
        "build_cmd": "pnpm build",
        "test_cmd": "pnpm test",
        "single_test_cmd": 'pnpm vitest run -t "<test name>"',
        "style_rule": "Format with Prettier; lint with ESLint.",
    },
    "generic": {
        "install_cmd": "<install command>",
        "runtime": "<language and version>",
        "build_cmd": "<build command>",
        "test_cmd": "<test command>",
        "single_test_cmd": "<single-test command>",
        "style_rule": "State one concrete, checkable style rule.",
    },
}


def render(project: str = "Project", stack: str = "generic") -> str:
    preset = _PRESETS.get(stack, _PRESETS["generic"])
    return TEMPLATE.format(
        project=project,
        overview=(
            "One or two sentences of non-obvious context an agent needs and "
            "cannot infer from the repo itself."
        ),
        protected_paths="`migrations/`, `generated/`",
        **preset,
    )
