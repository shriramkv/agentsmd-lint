"""agentsmd-lint: a linter and scaffolder for AGENTS.md files.

Public API:
    lint_text(path, text) -> LintResult
    lint_file(path)       -> LintResult
"""
from __future__ import annotations

__version__ = "0.1.0"

from .linter import LintResult, lint_file, lint_text
from .models import Finding, Severity
from .rules import RuleConfig

__all__ = [
    "__version__",
    "lint_text",
    "lint_file",
    "LintResult",
    "Finding",
    "Severity",
    "RuleConfig",
]
