"""Reporters render LintResults for humans (pretty) and machines (json)."""
from __future__ import annotations

import json
import sys

from .linter import LintResult
from .models import Severity

# ANSI colours, auto-disabled when not a TTY or NO_COLOR is set.
_COLORS = {
    Severity.ERROR: "\033[31m",   # red
    Severity.WARNING: "\033[33m",  # yellow
    Severity.INFO: "\033[36m",     # cyan
}
_BOLD = "\033[1m"
_DIM = "\033[2m"
_GREEN = "\033[32m"
_RESET = "\033[0m"

_SYMBOL = {Severity.ERROR: "x", Severity.WARNING: "!", Severity.INFO: "i"}


def _use_color(stream) -> bool:
    import os

    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(stream, "isatty") and stream.isatty()


def pretty(result: LintResult, stream=None) -> None:
    stream = stream or sys.stdout
    color = _use_color(stream)

    def c(text: str, code: str) -> str:
        return f"{code}{text}{_RESET}" if color else text

    header = f"{result.path}"
    stream.write(c(header, _BOLD) + "\n")

    if not result.findings:
        stream.write(c("  All checks passed. Clean, high-signal AGENTS.md.\n", _GREEN))
    else:
        for f in result.findings:
            sym = _SYMBOL[f.severity]
            loc = f"{f.location():>4}"
            sev = c(f.severity.value.upper(), _COLORS[f.severity])
            stream.write(f"  {c(sym, _COLORS[f.severity])} {c(loc, _DIM)}  {sev:<8} {f.rule_id}  {f.message}\n")
            if f.hint:
                stream.write(f"       {c('hint: ' + f.hint, _DIM)}\n")

    bar = _score_bar(result.score, color)
    stream.write(
        f"\n  score {c(str(result.score), _BOLD)}/100  {bar}"
        f"   {len(result.errors)} error(s), {len(result.warnings)} warning(s), "
        f"{len(result.infos)} info\n"
    )


def _score_bar(score: int, color: bool) -> str:
    filled = round(score / 10)
    bar = "#" * filled + "-" * (10 - filled)
    if not color:
        return f"[{bar}]"
    tone = _GREEN if score >= 80 else (_COLORS[Severity.WARNING] if score >= 50 else _COLORS[Severity.ERROR])
    return f"[{tone}{bar}{_RESET}]"


def to_json(results: list[LintResult]) -> str:
    payload = [
        {
            "path": r.path,
            "score": r.score,
            "ok": r.ok,
            "findings": [
                {
                    "rule": f.rule_id,
                    "severity": f.severity.value,
                    "line": f.line,
                    "message": f.message,
                    "hint": f.hint,
                }
                for f in r.findings
            ],
        }
        for r in results
    ]
    return json.dumps({"results": payload}, indent=2)
