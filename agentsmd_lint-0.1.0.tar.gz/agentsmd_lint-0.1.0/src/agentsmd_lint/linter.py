"""The linter engine: run all rules over a document and summarise results."""
from __future__ import annotations

from dataclasses import dataclass

from .models import Document, Finding, Severity
from .parser import parse
from .rules import RuleConfig, all_rules


@dataclass
class LintResult:
    """Aggregated outcome of linting a single file."""

    path: str
    findings: list[Finding]
    score: int  # 0-100, higher is better

    @property
    def errors(self) -> list[Finding]:
        return [f for f in self.findings if f.severity is Severity.ERROR]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity is Severity.WARNING]

    @property
    def infos(self) -> list[Finding]:
        return [f for f in self.findings if f.severity is Severity.INFO]

    @property
    def ok(self) -> bool:
        """Passes if there are no errors."""
        return not self.errors


def _score(findings: list[Finding]) -> int:
    """A simple, transparent 0-100 quality score.

    Errors cost the most, then warnings, then infos. Deliberately gentle so a
    solid-but-imperfect file still scores well and improvement feels reachable.
    """
    penalty = 0
    for f in findings:
        penalty += {Severity.ERROR: 20, Severity.WARNING: 7, Severity.INFO: 2}[
            f.severity
        ]
    return max(0, 100 - penalty)


def lint_text(path: str, text: str, config: RuleConfig | None = None) -> LintResult:
    """Lint raw text and return a result. Pure function - easy to unit test."""
    config = config or RuleConfig()
    doc: Document = parse(path, text)
    findings: list[Finding] = []
    for rule in all_rules():
        findings.extend(rule.run(doc, config))
    # Stable ordering: by line (None last), then severity, then rule id.
    findings.sort(
        key=lambda f: (f.line is None, f.line or 0, -f.severity.rank, f.rule_id)
    )
    return LintResult(path=path, findings=findings, score=_score(findings))


def lint_file(path: str, config: RuleConfig | None = None) -> LintResult:
    with open(path, "r", encoding="utf-8") as fh:
        return lint_text(path, fh.read(), config)
