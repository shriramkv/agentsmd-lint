"""Lightweight, dependency-free Markdown parser for AGENTS.md files.

We only need structure (headings, bodies, fenced code, frontmatter), so a full
CommonMark parser would be overkill. This keeps install weight near zero.
"""
from __future__ import annotations

import re

from .models import Document, Section

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
_FENCE_RE = re.compile(r"^(```|~~~)")


def parse(path: str, text: str) -> Document:
    """Parse raw AGENTS.md text into a structured Document."""
    lines = text.splitlines()
    has_frontmatter, start = _strip_frontmatter(lines)

    sections: list[Section] = []
    current: Section | None = None
    in_fence = False

    for idx in range(start, len(lines)):
        line = lines[idx]
        line_no = idx + 1  # 1-indexed for humans

        if _FENCE_RE.match(line.strip()):
            in_fence = not in_fence
            if current is not None:
                current.body_lines.append(line)
            continue

        heading = None if in_fence else _HEADING_RE.match(line)
        if heading:
            level = len(heading.group(1))
            title = heading.group(2).strip()
            current = Section(title=title, level=level, start_line=line_no)
            sections.append(current)
        else:
            if current is not None:
                current.body_lines.append(line)

    return Document(
        path=path,
        raw=text,
        lines=lines,
        sections=sections,
        has_frontmatter=has_frontmatter,
    )


def _strip_frontmatter(lines: list[str]) -> tuple[bool, int]:
    """Detect a leading YAML frontmatter block delimited by '---'.

    Returns (had_frontmatter, index_to_start_parsing_body).
    """
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                return True, i + 1
    return False, 0


def iter_code_blocks(section: Section) -> list[list[str]]:
    """Return the inner lines of each fenced code block within a section."""
    blocks: list[list[str]] = []
    current: list[str] | None = None
    for line in section.body_lines:
        if _FENCE_RE.match(line.strip()):
            if current is None:
                current = []
            else:
                blocks.append(current)
                current = None
        elif current is not None:
            current.append(line)
    if current is not None:  # unterminated fence; keep what we have
        blocks.append(current)
    return blocks
