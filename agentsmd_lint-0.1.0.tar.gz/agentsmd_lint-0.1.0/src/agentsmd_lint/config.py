"""Load RuleConfig from a TOML file (pyproject.toml or .agentsmd-lint.toml)."""
from __future__ import annotations

import os

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - fallback for 3.10
    import tomli as tomllib  # type: ignore

from .rules import RuleConfig

_LOCAL_FILE = ".agentsmd-lint.toml"


def load_config(start_dir: str = ".") -> RuleConfig:
    """Find and load configuration, falling back to defaults.

    Precedence: .agentsmd-lint.toml > [tool.agentsmd-lint] in pyproject.toml.
    """
    config = RuleConfig()

    local = os.path.join(start_dir, _LOCAL_FILE)
    if os.path.isfile(local):
        _apply(config, _read_toml(local))
        return config

    pyproject = os.path.join(start_dir, "pyproject.toml")
    if os.path.isfile(pyproject):
        data = _read_toml(pyproject)
        tool = data.get("tool", {}).get("agentsmd-lint", {})
        if tool:
            _apply(config, tool)

    return config


def _read_toml(path: str) -> dict:
    with open(path, "rb") as fh:
        return tomllib.load(fh)


def _apply(config: RuleConfig, data: dict) -> None:
    if "max_words" in data:
        config.max_words = int(data["max_words"])
    if "max_section_words" in data:
        config.max_section_words = int(data["max_section_words"])
    if "min_command_sections" in data:
        config.min_command_sections = int(data["min_command_sections"])
    if "recommended_sections" in data:
        config.recommended_sections = [str(s).lower() for s in data["recommended_sections"]]
    if "disable" in data:
        config.disabled_rules = {str(r).upper() for r in data["disable"]}
